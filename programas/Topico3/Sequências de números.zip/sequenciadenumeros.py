#processamento
c=int(input('informe por favor um valor inteiro possitivo: '))
i=0
#c=9
while(i<=c):
    a = i
    while(a <= c):
        print(f'{a} ', end='')
        #if (b == c):
        a += 1
    print('')
    c -= 1