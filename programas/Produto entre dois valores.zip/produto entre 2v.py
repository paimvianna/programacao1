#Entrada
v1 = int(input("Informe um valor: "))
v2 = int(input("Informe um valor: "))
#Processamento
saída = v1*v2
#Saída
print("O produto é ",saída)