#Entrada
saldoi = int(input("informe o saldo da sua carteira: "))
vlrser = int(input("informe o valor do pagamento do serviço: "))

#Processamento
mtate = saldoi + vlrser

#Saída
print ("Seu saldo montante e de: ", mtate)

#OBS se fosse float seria mais realista.