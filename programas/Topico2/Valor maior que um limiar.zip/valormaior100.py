#Entrada
valor = int(input('Informe o valor p/ testar: '))

#Processamento
if(valor>100):
    print('sim')
else:
    print('não')
#print('Fim')