#Entrada
a1=int(input(' '))
a2=int(input(' '))
a3=int(input(' '))
a4=int(input(' '))

#Processamento
media=(a1+a2+a3+a4)/4
if(a1>media):
    print(a1)

if(a2>media):
    print(a2)

if(a3>media):
    print(a3)

if(a4>media):
    print(a4)