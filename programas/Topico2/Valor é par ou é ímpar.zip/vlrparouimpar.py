#Entrada
valor=int(input('Informe o valor p/ teste: '))

#Processamento
resto=valor%2
if(resto==0):
    print('par')
else:
    print('impar')