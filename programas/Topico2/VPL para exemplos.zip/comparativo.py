#entrada
a= int(input('informe A'))
b= int(input('informe B'))
if (a>b):
    print ('A e maior que B')
print('Fim')
    