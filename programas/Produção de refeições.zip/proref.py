#Entrada
vjs = int(input("Por favor informe o numero de viajantes: "))
nds = int(input("Por favor informe o numero de dias de estadia: "))

#Processamneto
nrf = vjs*nds*3

#Saída
print ("A quantidade de refeições sera de: ",nrf)