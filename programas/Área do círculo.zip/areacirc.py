#Entrada
#from math import pi, pra usar esta biblioteca neste caso tenho que ver como definir a quantidade de casa decimais após o ponto.
pi = 3.1415
d = float(input("Por favor, informe o diametro do circulo em centimetros preferencialmente em valores inteiros: "))

#Processamento
area = pi*((d/2)**2)

#Saída
print (F"area {area:.2f}")
