# Meu primeiro programa

#Entrada

#Processamento
#pri = 'primeiro'
#Saída
print("Oi mundão véio!")
